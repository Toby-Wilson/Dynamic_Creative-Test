﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Diagnostics;

namespace ProductsDB
{
    /*
     * Class for downloading database .CSV files
     */
    class WebHelper
    {
        //file source reference
        private String sourceURL;

        //default constructor assumes dropbox repository
        public WebHelper()
        {
            sourceURL = "https://dl.dropboxusercontent.com/u/6582068/products.csv";
        }

        //overload constructor that accepts alternate URL
        public WebHelper(String fileURL)
        {
            sourceURL = fileURL;
        }

        /*
         * Retriever method for downloading expected file from the URL to locla file structure
         */
        public int Retriever()
        {
            try
            {

                using (WebClient downloader = new WebClient())
                {
                    downloader.DownloadFile(sourceURL, "products.csv");
                }

            }catch(Exception webException)
            {
                Debug.Write(webException.ToString());
            }

            return -1;
        }
    }
}
