﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Data;
using System.Collections;

//TODO: add in support for creation of new tables in ImportNewTable method

namespace ProductsDB
{
    /*
     * The DBManagr class handles basic database interactions including:
     * 
     * connection test for interchangable databases
     * .csv product table import/update
     * 
     * 
     * @author Toby Wilson
     */
    class DBManager
    {
        private OleDbConnection database;

        private String connectionString;
        private String activeDatabase;

        private String[] tempInput; //temp memory for loading .csv

        // constant query string components
        private const String SELECTALL = "SELECT * FROM ";

        /*
         * constructs a default DBmanager class with preset connection string
         */
        public DBManager()
        {
            connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=products.mdb";
            activeDatabase = "products.mdb";
            database = new OleDbConnection(connectionString);
        }

        /*
         *Overloaded constructor for creating additional databases/changing database resource
         */
        public DBManager(String databaseName)
        {
            connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + databaseName;
            activeDatabase = databaseName;
            database = new OleDbConnection(connectionString);
        }

        /*
         * for instantiating/testing this application's database element connections
         */
        public int TestOpenDB()
        {
            try
            {
                Debug.Write("Opening Selected Database. \n");
                database.Open();
                Debug.Write("Selected Database Opened. \n");
                return 0;

            }catch(Exception ConnectionError)
            {
                Debug.Write(ConnectionError.ToString());
                return -1;
            }
            finally
            {
                database.Close();
            }
            
        }

        /*
         * attempts to load paramater .csv file into the database
         */
        public int ImportNewTable(String FileName)
        {

            try
            {
                //attempt to parse the CSV into tempInput array
                ReadCSV(FileName);
                
                //TODO: add in support for creation of new tables in ImportNewTable method

                //insert table rows
                InsertOrUpdate();

                return 0;
            }catch(Exception LoadException)
            {
                Debug.Write(LoadException.ToString());
                return -1;
            }finally
            {
                database.Close();
            }

        }


        /*
         * text reader for loading CSV, saves each row in tempInput String array
         */
        private int ReadCSV(String FileName)
        {
            try
            {
                StreamReader fileIn = new StreamReader(FileName);
                String currentLine;
                List<String> lines = new List<String>();
                int count = 0;

                while((currentLine = fileIn.ReadLine()) != null)
                {
                    lines.Insert(count,currentLine);
                    //Debug.Write(currentLine +"\n");
                    count++;
                }

                tempInput = new String[1];
                tempInput = lines.ToArray();

                return 0;
            }catch(Exception FileReadError)
            {
                Debug.Write(FileReadError.ToString());
                return -1;
            }

        }

        /*
         * private helper function for running insert and update statements
         */
        private int InsertOrUpdate()
        {

            //schema values for each tupple
            String ID = "";
            String category = "";
            String productName = "";
            int price = 0;

            // 'I' indicates run insert statement, 'U' indicates entry exists and must be updated
            char typeFlag = 'I';

            String Update = "update Products set ID = ?, Category = ?,  ProductName = ?, Price = ?";
            String Insert = "INSERT INTO Products ([ID],[Category],[ProductName],[Price]) values (?,?,?,?)";


            //select statement for determining need to update
            OleDbCommand selectID = new OleDbCommand();

            selectID.CommandType = CommandType.Text;

            selectID.CommandText = "Select * from Products Where ID = ?";
            selectID.Connection = database;

            try
            {

                // if there is something to add, start at 1 as first index is schema data
                if (tempInput.Length > 1)
                {

                    OleDbCommand command = new OleDbCommand();
                    command.CommandType = CommandType.Text;
                    command.Connection = database;
                    
                    
                    for (int i = 1; i < tempInput.Length; i++)
                    {

                        //break each array item into individual values
                        ID = tempInput[i].Split(',').ElementAt(0);
                        category = tempInput[i].Split(',').ElementAt(1);
                        productName = tempInput[i].Split(',').ElementAt(2);
                        int.TryParse(tempInput[i].Split(',').ElementAt(3), out price);

                        //define the ID to look for
                        selectID.Parameters.AddWithValue("@ID", ID);

                        database.Open();

                        //if there is an element with the ID of this tupple, call an update command else, insert
                        if(selectID.ExecuteNonQuery() >=1)
                        {
                            typeFlag = 'U';
                            command.CommandText = Update;
                        }else
                        {
                            typeFlag = 'I';
                            command.CommandText = Insert;
                        }

                        command.Parameters.AddWithValue("@ID", ID);
                        command.Parameters.AddWithValue("@Category", category);
                        command.Parameters.AddWithValue("@ProductName", productName);
                        command.Parameters.AddWithValue("@Price", price);

                        //if this is an update we need an extra ID parameter
                        if(typeFlag == 'U')
                        {
                            command.Parameters.AddWithValue("@ID", ID);
                        }

                        //execute insert statement
                        command.ExecuteNonQuery();

                        //clear parameter lists
                        command.Parameters.Clear();
                        selectID.Parameters.Clear();

                        Debug.Write("Added Item: " + ID + " , " + category + " , " + productName + " , " + price + "\n");
                        database.Close();
                    }
                    
                    return 0;
                }else
                {
                    return -1;
                }

            }catch(Exception InsertUpdateException)
            {
                Debug.Write(InsertUpdateException.ToString());
                return -1;

            }finally
            {
                database.Close();
            }
        }
    }
}
